-- Resource Metadata
fx_version 'bodacious'
games { 'gta5' }

author 'rubbertoe98'
description 'prismantivdm'
version '1.0.0'

client_script "cl_prismantivdm.lua"
